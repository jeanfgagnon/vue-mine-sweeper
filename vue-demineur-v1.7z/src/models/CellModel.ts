export default class CellModel {
  public CellId = '';
  public CellNo = 0;
  public IsRedFlagVisible = false;
  public IsBomb = false;
  public IsCleared = false;
  public Text = '';
  public CssClass = '';
  public Style = '';

}