export default class CellCoords {
  public RowPos = 0;
  public ColPos = 0;
  public valid = false;
}